/* 文游工坊 Service Worker —— 首次加载后整站离线可用 */
const CACHE = 'wenyu-v11';

const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/fallback.css',
  './css/app.css',
  './css/player.css',
  './js/format.js',
  './js/store.js',
  './js/stage.js',
  './js/player.js',
  './js/io.js',
  './js/editor.js',
  './js/main.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE)
      .then((c) => c.addAll(ASSETS))
      .then(() => self.skipWaiting())
      .catch((err) => console.warn('[sw] precache partial:', err))
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  // 只接管同源资源，避免干扰其它站点
  if (url.origin !== self.location.origin) return;

  // 下载类请求一律不碰 —— 被缓存拦住的话，会反复下到旧版本的包
  if (/\/(get|download|download-full)$/.test(url.pathname) || /\.zip$/i.test(url.pathname)) return;

  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      if (hit) {
        fetch(req)
          .then((resp) => {
            if (resp && resp.ok) caches.open(CACHE).then((c) => c.put(req, resp.clone()));
          })
          .catch(() => {});
        return hit;
      }
      return fetch(req)
        .then((resp) => {
          if (resp && resp.ok && resp.type === 'basic') {
            const copy = resp.clone();
            caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
          }
          return resp;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});
